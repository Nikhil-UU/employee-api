const express = require('express');
const mongoose = require('mongoose');
const dotenv = require('dotenv');
const employeeRoutes = require('./routes/employeeRoutes');
const Employee = require('./models/Employee');

dotenv.config();
const app = express();

app.set('view engine', 'ejs');
app.set('views', './views');
app.use(express.static('public'));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.get('/', async (req, res) => {
    const employees = await Employee.find();
    res.render('index', { employees, editingEmp: null });
});

app.get('/edit/:id', async (req, res) => {
    const editingEmp = await Employee.findById(req.params.id);
    const employees = await Employee.find();
    res.render('index', { employees, editingEmp });
});


app.post('/create', async (req, res) => {
    const { id, name, position, department, salary } = req.body;
    if (id) {
        await Employee.findByIdAndUpdate(id, { name, position, department, salary });
    } else {
        await Employee.create({ name, position, department, salary });
    }
    res.redirect('/');
});


app.post('/delete/:id', async (req, res) => {
    await Employee.findByIdAndDelete(req.params.id);
    res.redirect('/');
});

app.use('/api/employees', employeeRoutes);
mongoose.connect(process.env.MONGO_URI)
    .then(() => {
        app.listen(process.env.PORT, () => {
            console.log(`✅ Server running at http://localhost:${process.env.PORT}`);
        });
    })
    .catch((err) => console.error('❌ MongoDB connection failed:', err));
