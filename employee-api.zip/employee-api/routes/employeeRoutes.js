const express = require('express');
const router = express.Router();
const controller = require('../controllers/employeeController');

// Secure API Key Middleware
router.use((req, res, next) => {
  const apiKey = req.headers['x-api-key'];
  if (apiKey !== process.env.API_KEY) {
    return res.status(403).json({ error: 'Forbidden: Invalid API Key' });
  }
  next();
});

router.post('/', controller.createEmployee);
router.get('/', controller.getEmployees);
router.get('/:id', controller.getEmployee);
router.put('/:id', controller.updateEmployee);
router.delete('/:id', controller.deleteEmployee);

module.exports = router;
